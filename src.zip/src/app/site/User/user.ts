export interface User {
    id:number;
    userid: string;
    firstName: string;
    lastName: string;
    age:number;
    gender:string;
    contact:number;
    pan:string;
    aadhar_number:string;
    password: string;
}
